# Systemd 定时任务迁移指南（替代 Hermes Cron 长任务）

## 问题根因

Hermes Cron 对所有任务（包括 `no_agent=true`）有 **3 分钟硬中断**。管线需要 1-2 小时，每次在第 3 分钟被 kill，状态显示 `error`。这是 Hermes scheduler 层限制，无法通过配置绕过。

## 创建的 systemd 文件

### 管线采集（每天 9:00 + 18:00）

**`/etc/systemd/system/wenyao-pipeline.service`**
```ini
[Unit]
Description=文鳐智投 全流程采集管线
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
WorkingDirectory=/root/.hermes/profiles/wenyaozhitou
ExecStart=/bin/bash /root/.hermes/profiles/wenyaozhitou/scripts/pipeline_master.sh
StandardOutput=journal
StandardError=journal
TimeoutStopSec=7200
User=root

Restart=on-failure
RestartSec=60
RestartMax=1
```

**`/etc/systemd/system/wenyao-pipeline.timer`**
```ini
[Unit]
Description=文鳐智投 定时采集（每天9:00 + 18:00）

[Timer]
OnCalendar=*-*-* 09:00:00
OnCalendar=*-*-* 18:00:00
Persistent=true
RandomizedDelaySec=120

[Install]
WantedBy=timers.target
```

### 日报（每天 20:00）

**服务**：`wenyao-dailyreport.service`（`TimeoutStopSec=600`）
**定时器**：`wenyao-dailyreport.timer`（`OnCalendar=*-*-* 20:00:00`）

### 凌晨自检（每天 03:00）

**服务**：`wenyao-selfheal.service`（`TimeoutStopSec=600`）
**定时器**：`wenyao-selfheal.timer`（`OnCalendar=*-*-* 03:00:00`）

## 部署命令

```bash
sudo cp /tmp/wenyao-*.service /etc/systemd/system/
sudo cp /tmp/wenyao-*.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable wenyao-pipeline.timer wenyao-dailyreport.timer wenyao-selfheal.timer
sudo systemctl start wenyao-pipeline.timer wenyao-dailyreport.timer wenyao-selfheal.timer
```

## 查看状态

```bash
systemctl list-timers 'wenyao-*' --no-pager
systemctl status wenyao-pipeline.service
journalctl -u wenyao-pipeline.service -f
```

## Hermes Cron 保留项

仅保留秒级/分钟级 watchdog 型脚本：
- `nginx_guard.sh`（每1分钟，`no_agent=true`）
- 记忆维护脚本（每天9:00）
